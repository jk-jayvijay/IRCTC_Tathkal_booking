#!/usr/bin/env python3
"""
Calibrate the static fare engine against LIVE erail data.

Fetches ~30 diverse routes, extracts per-class GN fares, converts to BASE fares
(subtracting reservation/superfast charges + GST for AC classes), filters out
catering-inclusive and flexi-surge trains (min-per-distance heuristic), and
emits a piecewise-linear lookup table (distance -> base fare per class) as
src/lib/rail/fares-calibration.ts
"""
import json, re, time, urllib.request, statistics

UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
NC = ["", "1A", "2A", "3A", "CC", "FC", "SL", "2S", "3E", "GN", "EA", "EC", "EV", "VC", "VS"]

RESERVATION = {'2S': 15, 'SL': 20, '3A': 40, '3E': 40, 'CC': 50, '2A': 50, '1A': 60, 'EA': 60, 'EC': 60}
SUPERFAST = {'2S': 15, 'SL': 30, '3A': 45, '3E': 45, 'CC': 45, '2A': 75, '1A': 75, 'EA': 75, 'EC': 75}
AC = {'1A', '2A', '3A', '3E', 'CC', 'EC', 'EA'}
EXCLUDE_NAME = re.compile(r'RAJDH|DURONTO|SHATAB|HUMSAF|VANDE|TEJAS|GATIM|SPECIAL|ANTYOD|JAN SHATAB', re.I)

ROUTES = [
    ('ERS', 'TVC'), ('ERS', 'QLN'), ('CLT', 'ERS'), ('TVC', 'KTYM'),
    ('MAS', 'SBC'), ('SBC', 'MAS'), ('MAS', 'TEN'), ('SBC', 'PUNE'),
    ('NDLS', 'JHS'), ('NDLS', 'BPL'), ('NDLS', 'LKO'), ('HWH', 'PNBE'),
    ('NDLS', 'ADI'), ('NDLS', 'JP'), ('MMCT', 'PUNE'), ('MMCT', 'ADI'),
    ('ERS', 'MMCT'), ('ERS', 'LTT'), ('TVC', 'MMCT'), ('ERS', 'NDLS'),
    ('NDLS', 'GHY'), ('NDLS', 'ERS'), ('SBC', 'ERS'), ('MAS', 'ERS'),
    ('NDLS', 'PNBE'), ('NDLS', 'HWH'), ('MMCT', 'NDLS'), ('SBC', 'NDLS'),
    ('TVC', 'SBC'), ('ERS', 'MAS'), ('NDLS', 'CBE'), ('PNBE', 'NDLS'),
]

def fetch(from_c, to_c):
    url = f'https://erail.in/rail/getTrains.aspx?Station_From={from_c}&Station_To={to_c}&DataSource=0&Language=0&Cache=true'
    req = urllib.request.Request(url, headers=UA)
    return urllib.request.urlopen(req, timeout=20).read().decode('utf-8', 'replace')

def parse(raw):
    points = []  # (distance, cls, gn_total, type, name)
    for rec in raw.split('^'):
        f = rec.split('~')
        if len(f) < 42 or not f[0].strip().isdigit():
            continue
        no, name = f[0].strip(), f[1].strip()
        if EXCLUDE_NAME.search(name):
            continue
        bitmap = (f[21] or '').ljust(15, '0')
        fare = next((x for x in f if re.match(r'^[A-Z_]+:\d+:', x)), None)
        if not fare:
            continue
        seg = fare.split(':')
        dist = int(seg[1])
        typ = seg[0]
        for c in range(1, len(NC)):
            cls = NC[c]
            if not cls or bitmap[c - 1] != '1' or c + 1 >= len(seg):
                continue
            slots = seg[c + 1].split(',')
            if not slots[0]:
                continue
            gn = int(slots[0])
            if gn > 0:
                points.append((dist, cls, gn, typ, no))
    return points

def to_base(dist, cls, gn, typ):
    base = gn - RESERVATION.get(cls, 20)
    if 'SUPERFAST' in typ or typ in ('RAJDHANI', 'DURONTO', 'HUMSAFAR', 'VANDE_BHARAT'):
        base -= SUPERFAST.get(cls, 30)
    if cls in AC:
        base = round(base / 1.05)
    return base if base > 0 else None

all_points = []
for a, b in ROUTES:
    try:
        pts = parse(fetch(a, b))
        all_points.extend(pts)
        print(f'{a}->{b}: {len(pts)} fare points')
    except Exception as e:
        print(f'{a}->{b}: FAILED {e}')
    time.sleep(0.4)

# bucket per (class, distance): keep MIN gn total (filters flexi surge & catering variants)
best = {}
for dist, cls, gn, typ, no in all_points:
    b = to_base(dist, cls, gn, typ)
    if b is None:
        continue
    key = (cls, dist)
    if key not in best or b < best[key]:
        best[key] = b

# build LUT: sorted distances, per class list of [dist, base]
by_class = {}
for (cls, dist), base in best.items():
    by_class.setdefault(cls, []).append([dist, base])
for cls in by_class:
    by_class[cls].sort()
    # dedupe close distances (keep min)
    dedup = []
    for d, v in by_class[cls]:
        if dedup and d - dedup[-1][0] < 25:
            if v < dedup[-1][1]:
                dedup[-1] = [d, v]
        else:
            dedup.append([d, v])
    by_class[cls] = dedup

# sanity: verify reconstruction error on the raw points
errors = []
for dist, cls, gn, typ, no in all_points:
    lut = by_class.get(cls)
    if not lut or dist < lut[0][0] or dist > lut[-1][0]:
        continue
    xs = [p[0] for p in lut]; ys = [p[1] for p in lut]
    # linear interp
    for i in range(len(xs) - 1):
        if xs[i] <= dist <= xs[i + 1]:
            t = (dist - xs[i]) / (xs[i + 1] - xs[i])
            base = ys[i] + t * (ys[i + 1] - ys[i])
            break
    total = base + RESERVATION.get(cls, 20)
    if 'SUPERFAST' in typ or typ in ('RAJDHANI', 'DURONTO', 'HUMSAFAR', 'VANDE_BHARAT'):
        total += SUPERFAST.get(cls, 30)
    if cls in AC:
        total = total * 1.05
    total = round(total)
    errors.append(abs(total - gn))
print(f'\nLUT sizes: { {k: len(v) for k, v in by_class.items()} }')
if errors:
    print(f'reconstruction: n={len(errors)} mean_err=₹{statistics.mean(errors):.1f} median=₹{statistics.median(errors)} p95=₹{sorted(errors)[int(len(errors)*0.95)]}')

out = {
    'generatedAt': '2026-10-08',
    'sources': len(ROUTES),
    'samples': len(all_points),
    'lut': by_class,
}
with open('/home/z/my-project/src/lib/rail/fares-calibration.json', 'w') as f:
    json.dump(out, f, separators=(',', ':'))
print('written fares-calibration.json')
