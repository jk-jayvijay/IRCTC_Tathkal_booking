"""Render the Tatkal architecture diagram HTML to a 2x PNG for PDF embedding."""
import asyncio
import os
from playwright.async_api import async_playwright

HTML = '/home/z/my-project/scripts/tatkal_diagram.html'
OUT = '/home/z/my-project/download/assets/tatkal_architecture.png'


async def html_to_image(html_path, output_path, selector='#root',
                        width=1000, height=None, scale=2):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(
            viewport={'width': width, 'height': height or 900},
            device_scale_factor=scale,
        )
        await page.goto(f'file://{html_path}', wait_until='networkidle')
        await page.wait_for_timeout(500)

        el = page.locator(selector)
        bbox = await el.bounding_box()
        if bbox:
            fit_w = max(width, int(bbox['width'] + 40))
            fit_h = int(bbox['height'] + 40)
            await page.set_viewport_size({'width': fit_w, 'height': fit_h})
            await page.wait_for_timeout(200)
            bbox = await el.bounding_box()
            print(f"content bbox: {bbox['width']:.0f} x {bbox['height']:.0f} css px")
        await el.screenshot(path=output_path)
        await browser.close()
        print(f'saved: {output_path} ({os.path.getsize(output_path)/1024:.0f} KB)')


if __name__ == '__main__':
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    asyncio.run(html_to_image(HTML, OUT))
