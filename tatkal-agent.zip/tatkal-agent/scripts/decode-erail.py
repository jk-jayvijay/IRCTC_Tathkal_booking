#!/usr/bin/env python3
"""Decode erail.in getTrains.aspx response format to understand fields + fare matrix."""
import re, sys, json

raw = open('/tmp/ndls_ers.txt', 'r', encoding='utf-8', errors='replace').read()

# Response structure: ~CODE~Name~CODE~Name~~timestamp~~~^train1^train2...
parts = raw.split('^')
print(f"Header: {parts[0][:120]!r}")
print(f"Num train records: {len(parts)-1}")

# Known real-world anchors (2025) for cross-check:
# 12626 KE RLD (NDLS->ERS ~2715km): SL ~800, 3A ~2110, 2A ~3005 (incl charges)
# 22656 NZM ERS SF (NZM->ERS ~2715km): similar

def dump(rec, idx):
    f = rec.split('~')
    print(f"\n=== TRAIN {idx}: {len(f)} fields ===")
    for i, v in enumerate(f[:60]):
        if v.strip():
            print(f"  [{i}] {v!r}")
    # fare segment typically starts at SUPERFAST: or MEXP:
    joined = rec
    m = re.search(r'(SUPERFAST|MEXP|MAIL_EXP|ord)?:?\d+:', joined)
    seg = re.search(r'~(SUPERFAST|MAIL|MEXP)[:~]', joined)
    if seg:
        pos = seg.start()
        print("  --- from type marker ---")
        tail = joined[pos:pos+900]
        for i, v in enumerate(tail.split('~')[:40]):
            if v.strip():
                print(f"  T[{i}] {v[:130]!r}")

for i, rec in enumerate(parts[1:4]):
    dump(rec, i)
