"""Merge cover PDF (Playwright) + body PDF (ReportLab) into the final deliverable."""
from pypdf import PdfReader, PdfWriter

A4_W, A4_H = 595.28, 841.89

COVER = '/home/z/my-project/scripts/tatkal_cover.pdf'
BODY = '/home/z/my-project/scripts/tatkal_body.pdf'
OUT = '/home/z/my-project/download/IRCTC_Tatkal_Booking_Agent_Plan.pdf'


def normalize_page_to_a4(page):
    box = page.mediabox
    w, h = float(box.width), float(box.height)
    if abs(w - A4_W) > 0.5 or abs(h - A4_H) > 0.5:
        page.scale_to(A4_W, A4_H)
    return page


writer = PdfWriter()
cover_page = PdfReader(COVER).pages[0]
writer.add_page(normalize_page_to_a4(cover_page))
for page in PdfReader(BODY).pages:
    writer.add_page(normalize_page_to_a4(page))
writer.add_metadata({
    '/Title': 'IRCTC Tatkal Booking Agent - Technical Plan and Build Roadmap',
    '/Author': 'Z.ai',
    '/Creator': 'Z.ai',
    '/Subject': 'Technical plan for a personal-use IRCTC Tatkal booking agent '
                '(Next.js dashboard, hybrid Playwright/AI engine, human-in-the-loop)',
})
with open(OUT, 'wb') as f:
    writer.write(f)
print('final PDF:', OUT, '| pages:', len(writer.pages))
