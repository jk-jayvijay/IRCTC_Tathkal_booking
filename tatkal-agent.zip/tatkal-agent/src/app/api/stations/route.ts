import { NextRequest, NextResponse } from 'next/server';
import { searchStations } from '@/lib/rail/stations';

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q') ?? '';
  const results = searchStations(q, 8);
  return NextResponse.json({
    stations: results.map((s) => ({ code: s.code, name: s.name, region: s.region })),
  });
}
