import { NextRequest, NextResponse } from 'next/server';
import { scanTrains } from '@/lib/rail/scan';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const from = sp.get('from') ?? '';
  const to = sp.get('to') ?? '';
  const date = sp.get('date') ?? undefined;
  const quota = (sp.get('quota') === 'GN' ? 'GN' : 'TQ') as 'GN' | 'TQ';

  if (!from || !to) {
    return NextResponse.json({ error: 'from and to station codes are required' }, { status: 400 });
  }
  try {
    const result = await scanTrains({ from, to, date, quota });
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'scan failed' },
      { status: 500 },
    );
  }
}
