import { NextRequest, NextResponse } from 'next/server';
import { createJob, listJobs } from '@/lib/rail/booking/store';
import { runMockBooking } from '@/lib/rail/booking/mock-engine';
import { runLiveBooking } from '@/lib/rail/booking/irctc-engine';
import { createGate, clearGates } from '@/lib/rail/booking/resolvers';
import { pushEvent } from '@/lib/rail/booking/types';
import type { BookingRequest } from '@/lib/rail/booking/types';

export const dynamic = 'force-dynamic';

export async function GET() {
  return NextResponse.json({ jobs: listJobs() });
}

export async function POST(req: NextRequest) {
  let body: Partial<BookingRequest>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'invalid JSON' }, { status: 400 });
  }
  if (!body.trainNo || !body.cls || !body.fromCode || !body.toCode || !body.date || !body.passengers?.length) {
    return NextResponse.json({ error: 'trainNo, cls, fromCode, toCode, date and passengers are required' }, { status: 400 });
  }
  const bookingReq: BookingRequest = {
    mode: body.mode === 'live' ? 'live' : 'mock',
    trainNo: body.trainNo,
    trainName: body.trainName,
    cls: body.cls,
    quota: body.quota === 'GN' ? 'GN' : 'TQ',
    fromCode: body.fromCode,
    toCode: body.toCode,
    date: body.date,
    passengers: body.passengers,
    irctcUser: body.irctcUser,
    upiId: body.upiId,
  };
  const job = createJob(bookingReq);
  pushEvent(job, 'queued', `Booking job ${job.id} queued (${bookingReq.mode} mode).`);

  // fire-and-forget; progress is polled via GET /api/bookings/[id].
  // Each user gate (captcha / review / payment) creates a FRESH promise.
  const runner = bookingReq.mode === 'live' ? runLiveBooking : runMockBooking;
  runner(job, () => createGate(job.id))
    .catch((e) => pushEvent(job, 'failed', e instanceof Error ? e.message : 'engine crash', 'error'))
    .finally(() => clearGates(job.id));

  return NextResponse.json({ job });
}
