import { NextRequest, NextResponse } from 'next/server';
import { getJob } from '@/lib/rail/booking/store';
import { resolveGate } from '@/lib/rail/booking/resolvers';
import { pushEvent } from '@/lib/rail/booking/types';

export const dynamic = 'force-dynamic';

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const job = getJob(id);
  if (!job) return NextResponse.json({ error: 'job not found' }, { status: 404 });
  return NextResponse.json({ job });
}

/** User resolves an awaiting_user gate: captcha answer, CONTINUE, or PAID. */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const job = getJob(id);
  if (!job) return NextResponse.json({ error: 'job not found' }, { status: 404 });
  let body: { answer?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'invalid JSON' }, { status: 400 });
  }
  const answer = (body.answer ?? '').trim();
  if (!answer) return NextResponse.json({ error: 'answer required' }, { status: 400 });

  const ok = resolveGate(id, answer);
  if (!ok) {
    return NextResponse.json({ error: 'job is not waiting for input', stage: job.stage }, { status: 409 });
  }
  pushEvent(job, job.stage, `User input received for ${job.awaiting?.kind ?? 'gate'}.`);
  return NextResponse.json({ ok: true });
}
