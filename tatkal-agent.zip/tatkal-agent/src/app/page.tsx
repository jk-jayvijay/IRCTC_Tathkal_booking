'use client';

import { useCallback, useEffect, useState } from 'react';
import { TrainFront, Search, Zap, Info } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { StationCombobox, type StationOption } from '@/components/tatkal/station-combobox';
import { ScanResults, type Selection } from '@/components/tatkal/scan-results';
import { BookingPanel } from '@/components/tatkal/booking-panel';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import type { ScanResult, ScanRow } from '@/lib/rail/scan';

function tomorrowISO(): string {
  const d = new Date(Date.now() + 24 * 3600 * 1000);
  return d.toISOString().slice(0, 10);
}

const STEPS = ['Journey', 'Trains & fares', 'Book'];

export default function Home() {
  const [from, setFrom] = useState<StationOption | null>({ code: 'ERS', name: 'Ernakulam Jn', region: 2 });
  const [to, setTo] = useState<StationOption | null>({ code: 'TVC', name: 'Thiruvananthapuram Central', region: 2 });
  const [date, setDate] = useState(tomorrowISO());
  const [quota, setQuota] = useState<'TQ' | 'GN'>('TQ');
  const [mode, setMode] = useState<'mock' | 'live'>('mock');

  const [scanning, setScanning] = useState(false);
  const [scan, setScan] = useState<(ScanResult & { rows?: ScanRow[] }) | null>(null);
  const [selected, setSelected] = useState<Selection | null>(null);

  const doScan = useCallback(async () => {
    if (!from || !to) return;
    setScanning(true);
    setSelected(null);
    try {
      const res = await fetch(`/api/scan?from=${from.code}&to=${to.code}&date=${date}&quota=${quota}`, { cache: 'no-store' });
      const data = await res.json();
      setScan(data);
    } catch {
      setScan({ error: 'Network error while scanning', } as ScanResult & { rows?: ScanRow[] } & { fromCode: string; toCode: string; date: string; quota: 'GN' | 'TQ'; source: 'live'; fetchedAt: string; trains: [] });
    } finally {
      setScanning(false);
    }
  }, [from, to, date, quota]);

  // auto-scan once on load (Kerala default route)
  useEffect(() => {
    doScan();
  }, []);

  const journey = {
    fromCode: from?.code ?? '',
    toCode: to?.code ?? '',
    date,
    quota,
  };

  return (
    <main className="min-h-screen bg-stone-100">
      {/* header */}
      <header className="bg-teal-800 text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-teal-700 border border-teal-600 flex items-center justify-center">
              <TrainFront className="h-5 w-5" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">Tatkal Agent</h1>
              <p className="text-[11px] text-teal-200">Live trains · live fares · live availability</p>
            </div>
          </div>
          <div className="flex items-center gap-1 rounded-lg bg-teal-900/60 p-1">
            {(['mock', 'live'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={cn(
                  'px-3 py-1.5 rounded-md text-xs font-semibold transition-colors uppercase tracking-wide',
                  mode === m ? 'bg-white text-teal-900' : 'text-teal-200 hover:text-white',
                )}
              >
                {m === 'live' ? 'Live IRCTC' : 'Simulated'}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-5">
        {/* how it works */}
        <div className="flex items-start gap-2.5 text-xs text-stone-600 bg-white border border-stone-200 rounded-lg px-4 py-3">
          <Info className="h-4 w-4 text-teal-700 mt-0.5 shrink-0" />
          <p>
            Train list, fares and availability are fetched <b>live</b> — one request to erail returns IRCTC-scraped
            schedules, General &amp; Tatkal fares and seat availability for the queried leg. IRCTC convenience fee
            (₹17.70 non-AC / ₹35.40 AC) is shown on top. Fares marked <b className="text-amber-600">EST</b> come from
            the calibrated static engine when a live value is missing. Payment is completed by you; the agent
            auto-detects the confirmation in-page (Option A).
          </p>
        </div>

        {/* step 1: journey */}
        <Card className="p-4 sm:p-5 border-stone-200">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-stone-900 text-sm flex items-center gap-2">
              <span className="h-5 w-5 rounded-full bg-teal-700 text-white text-[11px] font-bold flex items-center justify-center">1</span>
              Journey
            </h2>
            <Badge variant="outline" className="text-[10px] text-stone-500 border-stone-200">step 1 of 3</Badge>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <StationCombobox
              label="From"
              value={from ? `${from.name} (${from.code})` : ''}
              onSelect={(s) => setFrom(s)}
              placeholder="e.g. ERS / Ernakulam / Kochi"
            />
            <StationCombobox
              label="To"
              value={to ? `${to.name} (${to.code})` : ''}
              onSelect={(s) => setTo(s)}
              placeholder="e.g. TVC / Trivandrum / Kovalam"
            />
            <div className="sm:w-44">
              <label className="text-xs font-medium text-stone-500 mb-1.5 block">Journey date</label>
              <Input
                type="date"
                value={date}
                min={tomorrowISO()}
                onChange={(e) => setDate(e.target.value)}
                className="h-11 border-stone-200"
                aria-label="Journey date"
              />
            </div>
            <div className="sm:w-36">
              <label className="text-xs font-medium text-stone-500 mb-1.5 block">Quota</label>
              <div className="flex h-11 items-center rounded-md border border-stone-200 bg-white p-1">
                {(['TQ', 'GN'] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => setQuota(q)}
                    className={cn(
                      'flex-1 h-full rounded text-xs font-semibold transition-colors',
                      quota === q ? 'bg-teal-700 text-white' : 'text-stone-500 hover:text-stone-800',
                    )}
                  >
                    {q === 'TQ' ? 'Tatkal' : 'General'}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-3 flex justify-end">
            <Button onClick={doScan} disabled={scanning || !from || !to} className="bg-teal-700 hover:bg-teal-800 text-white">
              {scanning ? (
                <span className="h-4 w-4 mr-2 rounded-full border-2 border-white/40 border-t-white animate-spin inline-block" />
              ) : (
                <Search className="h-4 w-4 mr-2" />
              )}
              {scanning ? 'Fetching live…' : 'Scan live'}
            </Button>
          </div>
        </Card>

        {/* step 2: trains & fares */}
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h2 className="font-semibold text-stone-900 text-sm flex items-center gap-2">
              <span className="h-5 w-5 rounded-full bg-teal-700 text-white text-[11px] font-bold flex items-center justify-center">2</span>
              Trains &amp; fares — {from?.code} → {to?.code}
            </h2>
            {selected && (
              <span className="text-xs text-teal-700 font-medium">
                selected: {selected.trainNo} · {selected.cls}
              </span>
            )}
          </div>
          {scan ? (
            <ScanResults result={scan} loading={scanning} selected={selected} onSelect={setSelected} onRefresh={doScan} />
          ) : (
            <Card className="p-8 text-center text-sm text-stone-400">Run a scan to see live trains.</Card>
          )}
        </div>

        {/* step 3: book */}
        <div>
          <h2 className="font-semibold text-stone-900 text-sm flex items-center gap-2 mb-3 px-1">
            <span className="h-5 w-5 rounded-full bg-teal-700 text-white text-[11px] font-bold flex items-center justify-center">3</span>
            Book — {mode === 'live' ? 'live IRCTC driver' : 'simulated engine'}
          </h2>
          <BookingPanel mode={mode} selection={selected} journey={journey} />
        </div>
      </div>

      <footer className="mt-8 border-t border-stone-200 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-2 text-[11px] text-stone-400">
          <span className="flex items-center gap-1.5">
            <Zap className="h-3 w-3 text-amber-500" />
            Live data: erail.in (IRCTC-scraped) · Static fallback engine calibrated on 3,600+ live samples
          </span>
          <span>Not affiliated with IRCTC · Use responsibly under IRCTC terms</span>
        </div>
      </footer>
    </main>
  );
}
