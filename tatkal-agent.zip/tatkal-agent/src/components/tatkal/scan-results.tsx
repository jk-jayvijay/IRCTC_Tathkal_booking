'use client';

import { useState } from 'react';
import {
  TrainFront, Clock, RefreshCw, ChevronDown, Radio, AlertTriangle,
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import type { ScanResult, ScanRow } from '@/lib/rail/scan';
import type { AvlState } from '@/lib/rail/types';

export interface Selection {
  trainNo: string;
  trainName: string;
  cls: string;
  fare: number | null;
}

interface Props {
  result: ScanResult & { rows?: ScanRow[] };
  loading: boolean;
  selected: Selection | null;
  onSelect: (s: Selection) => void;
  onRefresh: () => void;
}

function fmtTime(t: string) {
  return t.replace('.', ':');
}

function AvlChip({ state, date, journeyDate }: { state: AvlState | null; date: string | null; journeyDate: string }) {
  if (!state || state.kind === 'unknown') {
    return <span className="text-xs text-stone-400">—</span>;
  }
  const notJourneyDate = date && date !== journeyDate;
  const suffix = notJourneyDate && date ? <span className="text-[10px] text-stone-400 ml-1">→ {date.slice(5)}</span> : null;
  switch (state.kind) {
    case 'available': {
      const tone = state.count >= 20
        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
        : state.count >= 1
          ? 'bg-amber-50 text-amber-700 border-amber-200'
          : 'bg-stone-100 text-stone-500 border-stone-200';
      return (
        <span className={cn('inline-flex items-center whitespace-nowrap text-xs font-medium border rounded-full px-2 py-0.5', tone)}>
          {state.count >= 1 ? <>AVL <b className="ml-1">{state.count}</b></> : 'FULL'}{suffix}
        </span>
      );
    }
    case 'rac':
      return <span className="inline-flex items-center whitespace-nowrap text-xs font-medium border rounded-full px-2 py-0.5 bg-violet-50 text-violet-700 border-violet-200">RAC {state.count}{suffix}</span>;
    case 'wl':
      return <span className="inline-flex items-center whitespace-nowrap text-xs font-medium border rounded-full px-2 py-0.5 bg-rose-50 text-rose-700 border-rose-200">WL {state.count}{suffix}</span>;
    case 'regret':
      return <span className="inline-flex items-center whitespace-nowrap text-xs font-medium border rounded-full px-2 py-0.5 bg-stone-100 text-stone-500 border-stone-200">Regret</span>;
  }
}

const CLASS_LABEL: Record<string, string> = {
  '1A': 'First AC', EA: 'Exec.Anand', EC: 'Exec CC', '3E': '3E Economy', '2A': 'AC 2-tier',
  '3A': 'AC 3-tier', CC: 'Chair Car', FC: 'First Class', SL: 'Sleeper', '2S': 'Second Sitting', GN: 'Unreserved',
};

export function ScanResults({ result, loading, selected, onSelect, onRefresh }: Props) {
  const [expanded, setExpanded] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((i) => (
          <Card key={i} className="p-5 animate-pulse">
            <div className="h-4 w-52 bg-stone-200 rounded mb-3" />
            <div className="h-3 w-72 bg-stone-100 rounded mb-4" />
            <div className="h-16 bg-stone-100 rounded" />
          </Card>
        ))}
      </div>
    );
  }

  if (result.error) {
    return (
      <Card className="p-6 border-amber-200 bg-amber-50">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
          <div>
            <p className="font-medium text-amber-900">Live scan unavailable</p>
            <p className="text-sm text-amber-800 mt-1">{result.error}</p>
            <Button size="sm" variant="outline" className="mt-3" onClick={onRefresh}>
              <RefreshCw className="h-3.5 w-3.5 mr-1.5" /> Retry live scan
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  const fetched = new Date(result.fetchedAt);
  const timeLabel = fetched.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="space-y-3">
      {/* source banner */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2 text-xs text-stone-500">
          <span className="inline-flex items-center gap-1.5 font-medium text-emerald-700">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
            LIVE
          </span>
          <span>erail snapshot · {timeLabel}{result.note ? ` · ${result.note}` : ''}</span>
        </div>
        <Button size="sm" variant="ghost" onClick={onRefresh} className="h-7 text-xs text-stone-500 hover:text-teal-700">
          <RefreshCw className="h-3 w-3 mr-1" /> Refresh
        </Button>
      </div>

      {result.rows?.map(({ train, classRows }) => (
        <Card key={train.no} className="overflow-hidden border-stone-200 hover:border-teal-300 transition-colors">
          {/* header */}
          <div className="px-4 sm:px-5 pt-4 pb-3 border-b border-stone-100">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <h3 className="font-semibold text-stone-900 truncate">
                  {train.name} <span className="text-stone-400 font-normal">#{train.no}</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5 flex items-center gap-2 flex-wrap">
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {fmtTime(train.depTime)} → {fmtTime(train.arrTime)}
                  </span>
                  <span>· {train.durationText.replace('.', 'h ')}m</span>
                  {train.distanceKm ? <span>· {train.distanceKm.toLocaleString('en-IN')} km</span> : null}
                  <span>· {train.daysLabel}</span>
                </p>
              </div>
              <Badge variant="outline" className="bg-stone-50 text-stone-600 border-stone-200 text-[10px] uppercase tracking-wide">
                <TrainFront className="h-3 w-3 mr-1" />
                {train.type.replace(/_/g, ' ')}
              </Badge>
            </div>
            {(train.legFromCode !== result.fromCode || train.legToCode !== result.toCode) && (
              <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-100 rounded px-2 py-1 mt-2 inline-block">
                Fares shown for {train.legFromName} ({train.legFromCode}) → {train.legToName} ({train.legToCode}) — nearest served leg.
              </p>
            )}
          </div>

          {/* classes: clean table */}
          <div className="divide-y divide-stone-50">
            {classRows.map((row) => {
              const isSel = selected?.trainNo === train.no && selected.cls === row.cls;
              const key = `${train.no}-${row.cls}`;
              const isOpen = expanded === key;
              return (
                <div
                  key={key}
                  role="button"
                  tabIndex={0}
                  onClick={() =>
                    onSelect({
                      trainNo: train.no,
                      trainName: train.name,
                      cls: row.cls,
                      fare: row.fare,
                    })
                  }
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      onSelect({ trainNo: train.no, trainName: train.name, cls: row.cls, fare: row.fare });
                    }
                  }}
                  className={cn(
                    'px-4 sm:px-5 py-2.5 cursor-pointer transition-colors',
                    isSel ? 'bg-teal-50/70' : 'hover:bg-stone-50',
                  )}
                >
                  <div className="grid grid-cols-[auto_1fr_auto_auto] items-center gap-x-3 sm:gap-x-5">
                    {/* class */}
                    <div className="w-24">
                      <span className={cn(
                        'font-mono text-xs font-bold rounded px-1.5 py-0.5 border',
                        isSel ? 'bg-teal-600 text-white border-teal-600' : 'bg-stone-50 text-stone-700 border-stone-200',
                      )}>
                        {row.cls}
                      </span>
                    </div>
                    {/* label */}
                    <div className="hidden sm:block text-xs text-stone-500 truncate">{CLASS_LABEL[row.cls] ?? ''}</div>
                    {/* fare */}
                    <div className="text-right min-w-[7.5rem]">
                      {row.fare != null ? (
                        <>
                          <span className="text-base font-semibold text-stone-900 tabular-nums">
                            ₹{row.fare.toLocaleString('en-IN')}
                          </span>
                          <span className="text-[10px] text-stone-400 ml-1">incl. ₹{row.convenienceFee} fee</span>
                          <span
                            className={cn(
                              'inline-flex items-center gap-1 text-[10px] font-semibold ml-2 align-middle',
                              row.fareSource === 'live' ? 'text-emerald-600' : 'text-amber-600',
                            )}
                            title={row.fareSource === 'live' ? 'Fare fetched from live data' : 'Estimated from the calibrated static engine'}
                          >
                            <Radio className="h-2.5 w-2.5" />
                            {row.fareSource === 'live' ? 'LIVE' : 'EST'}
                          </span>
                        </>
                      ) : (
                        <span className="text-xs text-stone-400">fare N/A</span>
                      )}
                    </div>
                    {/* availability */}
                    <div className="w-32 sm:w-40 text-right">
                      <AvlChip state={row.avl} date={row.avlDate} journeyDate={result.date} />
                    </div>
                  </div>
                  {/* breakdown (collapsible) */}
                  {row.breakdown && (
                    <div className="mt-1">
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); setExpanded(isOpen ? null : key); }}
                        className="text-[11px] text-stone-400 hover:text-teal-700 inline-flex items-center gap-1"
                      >
                        <ChevronDown className={cn('h-3 w-3 transition-transform', isOpen && 'rotate-180')} />
                        fare breakdown
                      </button>
                      {isOpen && (
                        <div className="text-[11px] text-stone-500 mt-1 grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-0.5 bg-stone-50 rounded-md px-3 py-2 w-fit">
                          <span>base <b className="text-stone-700">₹{row.breakdown.base}</b></span>
                          <span>reservation <b className="text-stone-700">₹{row.breakdown.reservation}</b></span>
                          <span>superfast <b className="text-stone-700">₹{row.breakdown.superfast}</b></span>
                          <span>{result.quota === 'TQ' ? 'tatkal' : 'tatkal (n/a)'} <b className="text-stone-700">₹{row.breakdown.tatkal}</b></span>
                          <span>GST 5% <b className="text-stone-700">₹{row.breakdown.gst}</b></span>
                          <span>IRCTC fee <b className="text-stone-700">₹{row.breakdown.convenience}</b></span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      ))}

      {result.rows?.length === 0 && (
        <Card className="p-8 text-center text-stone-500">
          No trains found for {result.fromName} → {result.toName}.
        </Card>
      )}
    </div>
  );
}
