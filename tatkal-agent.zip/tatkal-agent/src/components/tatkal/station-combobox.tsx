'use client';

import { useEffect, useRef, useState } from 'react';
import { MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

export interface StationOption {
  code: string;
  name: string;
  region: number;
}

interface Props {
  label: string;
  value: string;
  onSelect: (s: StationOption) => void;
  placeholder?: string;
}

const REGION_TAG = ['', 'South India', 'Kerala'];

export function StationCombobox({ label, value, onSelect, placeholder }: Props) {
  const [query, setQuery] = useState('');
  const [items, setItems] = useState<StationOption[]>([]);
  const [open, setOpen] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const ctrl = new AbortController();
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/stations?q=${encodeURIComponent(query)}`, { signal: ctrl.signal });
        const data = await res.json();
        setItems(data.stations ?? []);
        setHighlight(0);
      } catch {
        /* aborted */
      }
    }, 150);
    return () => {
      clearTimeout(t);
      ctrl.abort();
    };
  }, [query, open]);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const choose = (s: StationOption) => {
    onSelect(s);
    setOpen(false);
    setQuery('');
  };

  return (
    <div ref={boxRef} className="relative flex-1 min-w-0">
      <label className="text-xs font-medium text-stone-500 mb-1.5 block">{label}</label>
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-teal-600" />
        <Input
          value={open ? query : value}
          placeholder={placeholder ?? 'Station code or name'}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onKeyDown={(e) => {
            if (!open) return;
            if (e.key === 'ArrowDown') { e.preventDefault(); setHighlight((h) => Math.min(h + 1, items.length - 1)); }
            if (e.key === 'ArrowUp') { e.preventDefault(); setHighlight((h) => Math.max(h - 1, 0)); }
            if (e.key === 'Enter' && items[highlight]) { e.preventDefault(); choose(items[highlight]); }
            if (e.key === 'Escape') setOpen(false);
          }}
          className="pl-9 h-11 border-stone-200 focus-visible:ring-teal-600 bg-white"
          aria-label={label}
        />
      </div>
      {open && (
        <div className="absolute z-50 mt-1.5 w-full max-h-72 overflow-y-auto rounded-lg border border-stone-200 bg-white shadow-lg py-1">
          {items.length === 0 && <div className="px-3 py-3 text-sm text-stone-400">Type to search 9,241 stations…</div>}
          {items.map((s, i) => (
            <button
              key={s.code}
              type="button"
              onMouseDown={(e) => { e.preventDefault(); choose(s); }}
              onMouseEnter={() => setHighlight(i)}
              className={cn(
                'w-full text-left px-3 py-2 flex items-center gap-2.5 text-sm',
                i === highlight ? 'bg-teal-50' : 'bg-white',
              )}
            >
              <span className="font-mono text-xs font-semibold text-teal-700 bg-teal-50 border border-teal-100 rounded px-1.5 py-0.5 min-w-[3rem] text-center">
                {s.code}
              </span>
              <span className="truncate text-stone-800">{s.name}</span>
              {s.region > 0 && (
                <span className={cn('ml-auto text-[10px] whitespace-nowrap', s.region === 2 ? 'text-emerald-600' : 'text-amber-600')}>
                  {REGION_TAG[s.region]}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
