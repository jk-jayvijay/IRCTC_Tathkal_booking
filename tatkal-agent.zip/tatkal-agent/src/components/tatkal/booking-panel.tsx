'use client';

import { useEffect, useRef, useState } from 'react';
import {
  UserPlus, Trash2, Rocket, CheckCircle2, XCircle, Loader2, ShieldCheck, CreditCard,
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import type { Selection } from './scan-results';
import type { BookingJob } from '@/lib/rail/booking/types';

interface Props {
  mode: 'mock' | 'live';
  selection: Selection | null;
  journey: { fromCode: string; toCode: string; date: string; quota: 'GN' | 'TQ' };
}

interface Passenger {
  name: string;
  age: string;
  gender: 'M' | 'F' | 'T';
  berth: string;
}

const BERTHS = ['NO PREFERENCE', 'LOWER', 'MIDDLE', 'UPPER', 'SIDE LOWER'];

export function BookingPanel({ mode, selection, journey }: Props) {
  const [passengers, setPassengers] = useState<Passenger[]>([
    { name: '', age: '', gender: 'M', berth: 'NO PREFERENCE' },
  ]);
  const [irctcUser, setIrctcUser] = useState('');
  const [upiId, setUpiId] = useState('');
  const [job, setJob] = useState<BookingJob | null>(null);
  const [gateAnswer, setGateAnswer] = useState('');
  const [starting, setStarting] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);

  // poll job status while running/awaiting
  useEffect(() => {
    if (!job?.id || (job.status !== 'running' && job.status !== 'awaiting_user')) return;
    const t = setInterval(async () => {
      try {
        const res = await fetch(`/api/bookings/${job.id}`, { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          setJob(data.job);
        }
      } catch { /* transient */ }
    }, 1200);
    return () => clearInterval(t);
  }, [job?.id, job?.status]);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
  }, [job?.events.length]);

  const validPassengers = passengers.filter((p) => p.name.trim() && Number(p.age) > 0);
  const canStart = selection && validPassengers.length > 0 && (mode === 'mock' || irctcUser.trim());

  const addPassenger = () =>
    setPassengers((p) => [...p, { name: '', age: '', gender: 'M', berth: 'NO PREFERENCE' }]);

  const start = async () => {
    if (!canStart) return;
    setStarting(true);
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          trainNo: selection!.trainNo,
          trainName: selection!.trainName,
          cls: selection!.cls,
          quota: journey.quota,
          fromCode: journey.fromCode,
          toCode: journey.toCode,
          date: journey.date,
          passengers: validPassengers.map((p) => ({
            name: p.name.trim(), age: Number(p.age), gender: p.gender, berth: p.berth,
          })),
          irctcUser: irctcUser.trim() || undefined,
          upiId: upiId.trim() || undefined,
        }),
      });
      const data = await res.json();
      setJob(data.job);
      setGateAnswer('');
    } finally {
      setStarting(false);
    }
  };

  const resolveGate = async (answer: string) => {
    if (!job) return;
    await fetch(`/api/bookings/${job.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ answer }),
    });
    setGateAnswer('');
  };

  return (
    <div className="space-y-4">
      {/* passengers */}
      <Card className="p-4 sm:p-5 border-stone-200">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-stone-900 text-sm">Passengers</h3>
          <Button size="sm" variant="outline" onClick={addPassenger} className="h-8 text-xs border-stone-200">
            <UserPlus className="h-3.5 w-3.5 mr-1" /> Add
          </Button>
        </div>
        <div className="space-y-2.5">
          {passengers.map((p, i) => (
            <div key={i} className="grid grid-cols-[1fr_5rem_4.5rem_9rem_auto] gap-2 items-center">
              <Input
                placeholder="Full name"
                value={p.name}
                onChange={(e) => setPassengers((ps) => ps.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))}
                className="h-9 border-stone-200"
                aria-label={`Passenger ${i + 1} name`}
              />
              <Input
                placeholder="Age"
                inputMode="numeric"
                value={p.age}
                onChange={(e) => setPassengers((ps) => ps.map((x, j) => (j === i ? { ...x, age: e.target.value.replace(/\D/g, '').slice(0, 3) } : x)))}
                className="h-9 border-stone-200"
                aria-label={`Passenger ${i + 1} age`}
              />
              <Select value={p.gender} onValueChange={(v) => setPassengers((ps) => ps.map((x, j) => (j === i ? { ...x, gender: v as Passenger['gender'] } : x)))}>
                <SelectTrigger className="h-9 text-xs" aria-label={`Passenger ${i + 1} gender`}><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="M">Male</SelectItem>
                  <SelectItem value="F">Female</SelectItem>
                  <SelectItem value="T">Trans</SelectItem>
                </SelectContent>
              </Select>
              <Select value={p.berth} onValueChange={(v) => setPassengers((ps) => ps.map((x, j) => (j === i ? { ...x, berth: v } : x)))}>
                <SelectTrigger className="h-9 text-xs" aria-label={`Passenger ${i + 1} berth preference`}><SelectValue /></SelectTrigger>
                <SelectContent>{BERTHS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
              </Select>
              <Button
                size="sm" variant="ghost"
                className="h-9 w-9 p-0 text-stone-300 hover:text-rose-500"
                onClick={() => setPassengers((ps) => (ps.length > 1 ? ps.filter((_, j) => j !== i) : ps))}
                aria-label={`Remove passenger ${i + 1}`}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>

        {mode === 'live' && (
          <div className="grid sm:grid-cols-2 gap-2.5 mt-3">
            <Input
              placeholder="IRCTC username (live mode)"
              value={irctcUser}
              onChange={(e) => setIrctcUser(e.target.value)}
              className="h-9 border-stone-200"
              aria-label="IRCTC username"
            />
            <Input
              placeholder="UPI ID for payment"
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
              className="h-9 border-stone-200"
              aria-label="UPI ID"
            />
          </div>
        )}
      </Card>

      {/* start */}
      {!job && (
        <Button
          onClick={start}
          disabled={!canStart || starting}
          className="w-full h-12 bg-teal-700 hover:bg-teal-800 text-white font-semibold"
        >
          {starting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Rocket className="h-4 w-4 mr-2" />}
          {selection
            ? `Start ${mode === 'live' ? 'LIVE' : 'simulated'} booking — ${selection.trainNo} · ${selection.cls}${selection.fare ? ` · ₹${selection.fare.toLocaleString('en-IN')}` : ''}`
            : 'Select a train & class above'}
        </Button>
      )}

      {/* job timeline */}
      {job && (
        <Card className="border-stone-200 overflow-hidden">
          <div className="px-4 sm:px-5 py-3 border-b border-stone-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold text-teal-700">{job.id}</span>
              {job.status === 'running' && <Badge className="bg-teal-50 text-teal-700 border-teal-200"><Loader2 className="h-3 w-3 mr-1 animate-spin" />running</Badge>}
              {job.status === 'awaiting_user' && <Badge className="bg-amber-50 text-amber-700 border-amber-200">needs you</Badge>}
              {job.status === 'success' && <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200"><CheckCircle2 className="h-3 w-3 mr-1" />booked</Badge>}
              {job.status === 'failed' && <Badge className="bg-rose-50 text-rose-700 border-rose-200"><XCircle className="h-3 w-3 mr-1" />failed</Badge>}
            </div>
            <span className="text-[11px] text-stone-400 uppercase tracking-wide">{mode} engine</span>
          </div>

          {/* user gates */}
          {job.status === 'awaiting_user' && job.awaiting && (
            <div className="px-4 sm:px-5 py-4 bg-amber-50 border-b border-amber-100">
              <p className="text-sm font-medium text-amber-900 mb-2.5">{job.awaiting.prompt}</p>
              {job.awaiting.kind === 'payment' ? (
                <Button onClick={() => resolveGate('PAID')} className="bg-teal-700 hover:bg-teal-800 text-white">
                  <CreditCard className="h-4 w-4 mr-2" /> I completed the payment
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Input
                    value={gateAnswer}
                    onChange={(e) => setGateAnswer(e.target.value)}
                    placeholder={job.awaiting.kind === 'captcha' ? 'password|captcha (live) or any text (mock)' : 'CONTINUE'}
                    className="h-9 bg-white max-w-xs"
                    onKeyDown={(e) => e.key === 'Enter' && gateAnswer.trim() && resolveGate(gateAnswer)}
                    aria-label="Gate answer"
                  />
                  <Button onClick={() => resolveGate(gateAnswer)} className="bg-teal-700 hover:bg-teal-800 text-white h-9">
                    Submit
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* success card */}
          {job.status === 'success' && job.result && (
            <div className="px-4 sm:px-5 py-4 bg-emerald-50 border-b border-emerald-100">
              <div className="flex items-center gap-3">
                <ShieldCheck className="h-8 w-8 text-emerald-600" />
                <div>
                  <p className="text-lg font-bold text-emerald-900 tracking-wider">
                    {job.result.pnr ?? 'CONFIRMED'}
                  </p>
                  <p className="text-xs text-emerald-700">
                    Payment auto-detected {job.result.paymentDetectedAt ? new Date(job.result.paymentDetectedAt).toLocaleTimeString('en-IN') : ''} · method: {job.result.detectionMethod}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* timeline */}
          <div ref={logRef} className="px-4 sm:px-5 py-3 max-h-64 overflow-y-auto bg-stone-50/60">
            {job.events.map((ev, i) => (
              <div key={i} className="flex items-start gap-2.5 py-1 text-xs">
                <span className="text-stone-400 font-mono shrink-0">
                  {new Date(ev.at).toLocaleTimeString('en-IN', { hour12: false })}
                </span>
                <span
                  className={cn(
                    'shrink-0 w-1.5 h-1.5 rounded-full mt-1.5',
                    ev.level === 'success' ? 'bg-emerald-500' : ev.level === 'warn' ? 'bg-amber-500' : ev.level === 'error' ? 'bg-rose-500' : 'bg-stone-300',
                  )}
                />
                <span className={cn(
                  ev.level === 'error' ? 'text-rose-700' : ev.level === 'warn' ? 'text-amber-800' : ev.level === 'success' ? 'text-emerald-800' : 'text-stone-600',
                )}>
                  {ev.message}
                </span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
