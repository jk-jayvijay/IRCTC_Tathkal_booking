/**
 * LIVE train/fare/availability client for erail.in (no API key required).
 *
 * Single request `getTrains.aspx?Station_From=X&Station_To=Y` returns, per train:
 *  - schedule (dep/arr/duration/days/classes/distance/type)
 *  - inline fare matrix for the queried leg:  TYPE:DIST:g1:g2:...  where group g[c+1]
 *    belongs to class index c (order: "",1A,2A,3A,CC,FC,SL,2S,3E,GN,EA,EC,EV,VC,VS)
 *    and slots are [GN_adult, GN_child, s2, TQ_charge, s4, TQ_child];
 *    TQ_adult = GN_adult + TQ_charge   (verified against erail's own parser)
 *  - inline availability cells per class for upcoming run dates
 *    (cross-verified against erail's data2.aspx?action=GetTrain per-segment data)
 *
 * Everything is parsed defensively — erail's format may vary slightly per train.
 */
import type { AvlCell, AvlState, ClassFareAvl, TrainOption } from './types';

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';

/** erail class order — index c in fare groups / classes bitmap */
const N_CLASSES = ['', '1A', '2A', '3A', 'CC', 'FC', 'SL', '2S', '3E', 'GN', 'EA', 'EC', 'EV', 'VC', 'VS'];

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export interface ErailFetchResult {
  trains: TrainOption[];
  rawCount: number;
}

function toMin(t: string): number {
  const m = /^(\d{1,2})\.(\d{2})$/.exec(t.trim());
  if (!m) return 0;
  return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
}

/** Parse availability token → typed state */
function parseAvlToken(tok: string, date: string): AvlCell {
  const t = tok.trim().toUpperCase().replace(/\s+/g, '');
  if (!t) return { date, state: { kind: 'unknown', raw: '-' } };
  const num = parseInt(t, 10);
  if (!Number.isNaN(num) && /^\d+$/.test(t)) return { date, state: { kind: 'available', count: num } };
  let m = /^WL(\d+)$/.exec(t);
  if (m) return { date, state: { kind: 'wl', count: parseInt(m[1], 10) } };
  m = /^RAC(\d+)$/.exec(t);
  if (m) return { date, state: { kind: 'rac', count: parseInt(m[1], 10) } };
  if (t.startsWith('REGRET') || t === 'NOTAVL' || t === 'NOTAVAILABLE' || t === 'NA')
    return { date, state: { kind: 'regret' } };
  return { date, state: { kind: 'unknown', raw: tok.trim() } };
}

/** Upcoming run dates (IST) for a Mon..Sun bitmap, starting `from`, taking `n` */
export function upcomingRunDates(days: boolean[], from: Date, n: number): string[] {
  const out: string[] = [];
  const d = new Date(from.getTime());
  // erail anchors at server "today" IST; caller passes IST-normalized date
  for (let i = 0; i < 60 && out.length < n; i++) {
    const dow = (d.getUTCDay() + 6) % 7; // Monday=0
    if (days[dow]) {
      out.push(d.toISOString().slice(0, 10));
    }
    d.setUTCDate(d.getUTCDate() + 1);
  }
  return out;
}

/** "today" in IST as yyyy-mm-dd (erail's availability anchor) */
export function istToday(): string {
  const now = new Date(Date.now() + 5.5 * 3600 * 1000);
  return now.toISOString().slice(0, 10);
}

function parseAvailabilityField(field: string, dates: string[]): Map<string, ClassFareAvl['avl']> {
  // e.g. "2A:31:28:10:8:::::::|3A:65:278:12:20:::::::2|3E:275::12::::::::|SL:94:96:12:28::6:::::4|"
  const map = new Map<string, ClassFareAvl['avl']>();
  for (const seg of field.split('|')) {
    const parts = seg.split(':');
    if (parts.length < 2) continue;
    const cls = parts[0].trim();
    if (!/^[A-Z0-9]{1,2}$/.test(cls)) continue; // class codes like 2A, 3A, 3E, SL, CC
    const cells = parts.slice(1);
    const avl: ClassFareAvl['avl'] = [];
    for (let i = 0; i < cells.length && i < dates.length; i++) {
      if (!cells[i]) continue;
      avl.push(parseAvlToken(cells[i], dates[i]));
    }
    map.set(cls, avl);
  }
  return map;
}

function findAvailabilityField(fields: string[]): string | null {
  for (const f of fields) {
    if (f.includes('|') && /^[A-Z0-9]{1,2}:/.test(f)) return f;
  }
  return null;
}

function parseFareString(fare: string, classesBitmap: string): Map<string, { gn: number; gnChild: number; tq: number | null; tqChild: number | null; tqCharge: number }> {
  const out = new Map<string, { gn: number; gnChild: number; tq: number | null; tqChild: number | null; tqCharge: number }>();
  const seg = fare.split(':');
  // seg[0] = type, seg[1] = distance, seg[c+1] = group for class index c
  for (let c = 1; c < N_CLASSES.length; c++) {
    const cls = N_CLASSES[c];
    if (!cls) continue;
    const present = classesBitmap[c - 1] === '1';
    const group = seg[c + 1];
    if (!present || !group) continue;
    const slots = group.split(',');
    const gnRaw = slots[0] ?? '';
    if (!gnRaw) continue;
    const gn = parseInt(gnRaw, 10) || 0;
    if (gn <= 0) continue;
    const gnChild = parseInt(slots[1] ?? '0', 10) || 0;
    const tqCharge = parseInt(slots[3] ?? '0', 10) || 0;
    const tqChild = parseInt(slots[5] ?? '0', 10) || 0;
    out.set(cls, {
      gn,
      gnChild,
      tq: tqCharge > 0 ? gn + tqCharge : null,
      tqChild: tqCharge > 0 ? tqChild : null,
      tqCharge,
    });
  }
  return out;
}

export async function fetchTrainsLive(fromCode: string, toCode: string, timeoutMs = 12000): Promise<ErailFetchResult> {
  const url = `https://erail.in/rail/getTrains.aspx?Station_From=${encodeURIComponent(fromCode)}&Station_To=${encodeURIComponent(toCode)}&DataSource=0&Language=0&Cache=true`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { 'User-Agent': UA, Accept: 'text/plain,*/*' },
      signal: ctrl.signal,
      cache: 'no-store',
    });
    if (!res.ok) throw new Error(`erail HTTP ${res.status}`);
    const raw = await res.text();
    return { ...parseErailResponse(raw), rawCount: raw.length };
  } finally {
    clearTimeout(timer);
  }
}

export function parseErailResponse(raw: string): { trains: TrainOption[] } {
  const trains: TrainOption[] = [];
  for (const rec of raw.split('^')) {
    const f = rec.split('~');
    if (f.length < 40) continue;
    const no = (f[0] ?? '').trim();
    if (!/^\d{4,5}$/.test(no)) continue; // train records start with a 5-digit number
    try {
      const name = (f[1] ?? '').trim();
      const days = (f[13] ?? '0000000').padEnd(7, '0').split('').map((c) => c === '1');
      const classesBitmap = (f[21] ?? '').padEnd(15, '0');
      const depTime = (f[10] ?? '').trim() || '00.00';
      const arrTime = (f[11] ?? '').trim() || '00.00';
      const durationText = (f[12] ?? '').trim() || '00.00';
      const type = ((f[32] ?? '').trim() || 'MAIL_EXPRESS').toUpperCase();
      const fareField = f.find((x) => /^[A-Z_]+:\d+:/.test(x)) ?? '';
      const distanceKm = fareField ? parseInt(fareField.split(':')[1], 10) || null : null;

      const fareMap = fareField ? parseFareString(fareField, classesBitmap) : new Map();
      const avlField = findAvailabilityField(f);
      const avlByClass = avlField
        ? parseAvailabilityField(avlField, upcomingRunDates(days, new Date(istToday() + 'T00:00:00Z'), 14))
        : new Map<string, ClassFareAvl['avl']>();

      const classes: ClassFareAvl[] = [];
      for (const [cls, fr] of fareMap) {
        if (cls === 'GN') continue; // unreserved — not reservation-bookable
        classes.push({
          cls,
          gnTotal: fr.gn,
          gnChild: fr.gnChild || null,
          tqTotal: fr.tq,
          tqKnown: fr.tq !== null,
          avl: avlByClass.get(cls) ?? [],
        });
      }
      // classes present in bitmap but with no fare data
      for (let c = 1; c < N_CLASSES.length; c++) {
        const cls = N_CLASSES[c];
        if (!cls || classesBitmap[c - 1] !== '1' || cls === 'GN') continue;
        if (!classes.some((x) => x.cls === cls)) {
          classes.push({ cls, gnTotal: null, gnChild: null, tqTotal: null, tqKnown: false, avl: avlByClass.get(cls) ?? [] });
        }
      }
      // order classes sensibly
      const order = ['EA', '1A', 'EC', '3E', '2A', '3A', 'CC', 'FC', 'SL', '2S', 'GN'];
      classes.sort((a, b) => order.indexOf(a.cls) - order.indexOf(b.cls));

      trains.push({
        no,
        name,
        type,
        fromCode: (f[3] ?? '').trim(),
        fromName: (f[2] ?? '').trim(),
        toCode: (f[5] ?? '').trim(),
        toName: (f[4] ?? '').trim(),
        legFromCode: (f[7] ?? f[3] ?? '').trim(),
        legFromName: (f[6] ?? f[2] ?? '').trim(),
        legToCode: (f[9] ?? f[5] ?? '').trim(),
        legToName: (f[8] ?? f[4] ?? '').trim(),
        depTime,
        arrTime,
        durationText,
        durationMin: toMin(durationText),
        days,
        daysLabel: days.every(Boolean) ? 'Daily' : days.map((d, i) => (d ? DAY_LABELS[i] : null)).filter(Boolean).join(' '),
        distanceKm,
        classes,
      });
    } catch {
      // skip malformed record
    }
  }
  return { trains };
}
