// ─── Core domain types for the Tatkal agent ─────────────────────────────

export interface Station {
  code: string;
  name: string;
  /** 2 = Kerala, 1 = South India, 0 = other (used for ranking) */
  region: number;
}

export type AvlState =
  | { kind: 'available'; count: number }
  | { kind: 'rac'; count: number }
  | { kind: 'wl'; count: number }
  | { kind: 'regret' }
  | { kind: 'unknown'; raw: string };

export interface AvlCell {
  /** ISO date (yyyy-mm-dd) this cell refers to */
  date: string;
  state: AvlState;
}

export interface ClassFareAvl {
  cls: string;
  /** live General-quota total fare (incl. reservation+superfast+GST, excl. convenience fee) */
  gnTotal: number | null;
  gnChild: number | null;
  /** live Tatkal total fare (null when not published) */
  tqTotal: number | null;
  /** true when the tatkal delta looked genuine (h[3] > 0) */
  tqKnown: boolean;
  /** live availability for the next run dates */
  avl: AvlCell[];
}

export interface TrainOption {
  no: string;
  name: string;
  type: string;
  /** train's own terminal endpoints */
  fromCode: string;
  fromName: string;
  toCode: string;
  toName: string;
  /** the actual travelled leg used for fare/availability (may differ from query endpoints) */
  legFromCode: string;
  legFromName: string;
  legToCode: string;
  legToName: string;
  depTime: string; // HH.MM
  arrTime: string; // HH.MM
  durationText: string; // HH.MM
  durationMin: number;
  /** runs-on bitmap Mon..Sun */
  days: boolean[];
  daysLabel: string;
  distanceKm: number | null;
  classes: ClassFareAvl[];
}

export type DataSource = 'live' | 'fallback';

export interface ScanResult {
  fromCode: string;
  fromName: string;
  toCode: string;
  toName: string;
  /** journey date requested (yyyy-mm-dd) */
  date: string;
  quota: 'GN' | 'TQ';
  source: DataSource;
  fetchedAt: string;
  trains: TrainOption[];
  note?: string;
  error?: string;
}

// ─── Static fare engine types (fallback estimator) ──────────────────────

export interface FareBreakdown {
  base: number;
  reservation: number;
  superfast: number;
  tatkal: number;
  gst: number;
  convenience: number;
  total: number;
}

export const BOOKING_CLASSES = ['1A', '2A', '3A', '3E', 'CC', 'EC', 'SL', '2S'] as const;
export type BookingClass = (typeof BOOKING_CLASSES)[number];

export const AC_CLASSES = new Set(['1A', '2A', '3A', '3E', 'CC', 'EC', 'EA']);
