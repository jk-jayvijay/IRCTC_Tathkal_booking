import type { BookingJob, BookingRequest } from './types';

// Store on globalThis — Next.js compiles route modules separately, so plain
// module-level Maps are NOT shared across route boundaries in the same process.
const g = globalThis as unknown as { __tatkalJobs?: Map<string, BookingJob> };
const jobs = g.__tatkalJobs ?? (g.__tatkalJobs = new Map<string, BookingJob>());

export function saveJob(job: BookingJob) {
  jobs.set(job.id, job);
}

export function getJob(id: string): BookingJob | undefined {
  return jobs.get(id);
}

export function listJobs(): BookingJob[] {
  return [...jobs.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function createJob(req: BookingRequest): BookingJob {
  const job: BookingJob = {
    id: `BK${Date.now().toString(36).toUpperCase()}${Math.floor(Math.random() * 90 + 10)}`,
    req,
    stage: 'queued',
    status: 'running',
    events: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  saveJob(job);
  return job;
}

export type { BookingJob, BookingRequest };
