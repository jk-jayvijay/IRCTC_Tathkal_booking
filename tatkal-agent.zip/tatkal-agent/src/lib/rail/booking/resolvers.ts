// Gate registry — connects engine "awaiting_user" gates to user input
// arriving via POST /api/bookings/[id]/resolve.
// Each gate call (captcha, review, payment) creates a FRESH one-shot promise;
// user answers are delivered to the oldest pending gate.

type Resolver = (answer: string) => void;

// globalThis for the same reason as store.ts (per-route module instances).
const g = globalThis as unknown as { __tatkalGates?: Map<string, Resolver[]> };
const gates = g.__tatkalGates ?? (g.__tatkalGates = new Map<string, Resolver[]>());

/** Engine-side: create a new gate and await the user's answer. */
export function createGate(jobId: string): Promise<string> {
  return new Promise((resolve) => {
    const arr = gates.get(jobId) ?? [];
    arr.push(resolve);
    gates.set(jobId, arr);
  });
}

/** API-side: deliver the answer to the oldest pending gate. */
export function resolveGate(jobId: string, answer: string): boolean {
  const arr = gates.get(jobId);
  if (!arr || arr.length === 0) return false;
  const r = arr.shift()!;
  r(answer);
  return true;
}

export function pendingGates(jobId: string): number {
  return gates.get(jobId)?.length ?? 0;
}

export function clearGates(jobId: string) {
  gates.delete(jobId);
}
