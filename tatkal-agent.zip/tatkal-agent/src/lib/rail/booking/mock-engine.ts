/**
 * MOCK booking engine — full simulation of the IRCTC flow with the same
 * stage machine, awaiting-user gates (captcha, payment) and Option A
 * payment-detection polling as the live driver. Deterministic-ish with
 * realistic timings so the whole pipeline can be exercised end-to-end.
 */
import { randomInt } from 'crypto';
import { pushEvent, type BookingJob } from './types';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function fakePnr(): string {
  return String(randomInt(2, 9)) + Array.from({ length: 9 }, () => randomInt(0, 10)).join('');
}

/** Simulated captcha text the "user" must solve — in mock, any input passes unless it's empty. */
function makeCaptcha(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from({ length: 5 }, () => chars[randomInt(0, chars.length)]).join('');
}

export async function runMockBooking(job: BookingJob, captchaAnswer: () => Promise<string>): Promise<void> {
  const { req } = job;
  try {
    pushEvent(job, 'login', `Connecting to IRCTC (simulated) as ${req.irctcUser ?? 'demo-user'}…`);
    await sleep(700);
    pushEvent(job, 'login', 'Session established. Retrying aggressively at T-0 if queue drop occurs.', 'success');

    // ── captcha gate ──
    const captcha = makeCaptcha();
    job.status = 'awaiting_user';
    job.awaiting = { kind: 'captcha', prompt: `Enter the captcha shown on IRCTC (simulated: ${captcha})` };
    pushEvent(job, 'captcha', 'Captcha displayed — waiting for user to solve.', 'warn', { captcha });
    const answer = await captchaAnswer();
    job.status = 'running';
    job.awaiting = undefined;
    if (!answer.trim()) throw new Error('Empty captcha');
    pushEvent(job, 'captcha', 'Captcha accepted.', 'success');

    // ── search & fill ──
    await sleep(500);
    pushEvent(job, 'search_fill', `Filling journey: ${req.fromCode} → ${req.toCode} on ${req.date}, class ${req.cls}, quota ${req.quota}`);
    await sleep(600);
    pushEvent(job, 'search_fill', `Train ${req.trainNo}${req.trainName ? ' ' + req.trainName : ''} located. Clicking Book Now.`, 'success');

    // ── passengers ──
    await sleep(500);
    for (const p of req.passengers) {
      pushEvent(job, 'passengers', `Added passenger: ${p.name}, ${p.age}/${p.gender}${p.berth ? ', pref ' + p.berth : ''}`);
      await sleep(250);
    }
    pushEvent(job, 'passengers', `${req.passengers.length} passenger(s) filled.`, 'success');

    // ── review ──
    await sleep(600);
    pushEvent(job, 'review', 'Review page reached. Details look consistent.', 'success');

    // ── submit ──
    await sleep(700);
    // small chance of IRCTC-style hiccups so retry logic is exercised
    if (randomInt(0, 10) === 0) {
      pushEvent(job, 'submit', 'IRCTC responded "Booking in progress — timeout". Auto-retrying once…', 'warn');
      await sleep(1200);
    }
    pushEvent(job, 'submit', 'Passenger details submitted. Payment gateway selection next.', 'success');

    // ── payment gate ──
    job.status = 'awaiting_user';
    job.awaiting = {
      kind: 'payment',
      prompt: `Complete the payment in the browser window (UPI ${req.upiId ?? '…'}). The agent will auto-detect the confirmation — do NOT close the window.`,
    };
    pushEvent(job, 'payment', `Payment page open (simulated). UPI: ${req.upiId ?? 'default'}. Waiting for user to pay.`, 'warn');
    // The UI "completes" payment by calling the captcha-like resolver again with 'PAID'
    const paySignal = await captchaAnswer();
    job.status = 'running';
    job.awaiting = undefined;
    if (paySignal !== 'PAID') throw new Error('Payment aborted by user');

    // ── Option A: in-page payment detection (simulated polling) ──
    pushEvent(job, 'payment_detect', 'Watching the IRCTC page for booking confirmation (in-page detection)…');
    for (let i = 1; i <= 4; i++) {
      await sleep(900);
      pushEvent(job, 'payment_detect', `Poll ${i}: page state = "processing"…`);
    }
    const pnr = fakePnr();
    pushEvent(job, 'payment_detect', 'Confirmation detected: "Ticket has been booked successfully" + PNR found in DOM.', 'success');
    job.status = 'success';
    job.result = {
      pnr,
      fare: 0,
      paymentDetectedAt: new Date().toISOString(),
      detectionMethod: 'simulated',
      ticketRef: `SIM-${pnr}`,
    };
    pushEvent(job, 'ticket', `PNR ${pnr} — e-ticket ready for download.`, 'success');
    pushEvent(job, 'done', 'Booking flow complete.', 'success');
  } catch (e) {
    job.status = 'failed';
    pushEvent(job, 'failed', e instanceof Error ? e.message : 'Unknown failure', 'error');
  }
}

export { makeCaptcha };
