// ─── Booking pipeline shared types ──────────────────────────────────────

export type BookingStage =
  | 'queued'
  | 'login'
  | 'captcha'
  | 'search_fill'
  | 'passengers'
  | 'review'
  | 'submit'
  | 'payment'
  | 'payment_detect'
  | 'ticket'
  | 'done'
  | 'failed';

export type BookingStatus = 'running' | 'awaiting_user' | 'success' | 'failed';

export interface BookingPassenger {
  name: string;
  age: number;
  gender: 'M' | 'F' | 'T';
  berth?: 'LOWER' | 'MIDDLE' | 'UPPER' | 'SIDE LOWER' | 'NO PREFERENCE';
  food?: 'NO' | 'V' | 'N';
}

export interface BookingRequest {
  mode: 'mock' | 'live';
  trainNo: string;
  trainName?: string;
  cls: string;
  quota: 'GN' | 'TQ';
  fromCode: string;
  toCode: string;
  date: string; // yyyy-mm-dd
  passengers: BookingPassenger[];
  irctcUser?: string; // live mode only — password kept client-side only, never stored
  upiId?: string;
}

export interface BookingEvent {
  at: string;
  stage: BookingStage;
  message: string;
  level: 'info' | 'warn' | 'error' | 'success';
  data?: Record<string, unknown>;
}

export interface BookingResult {
  pnr?: string;
  fare?: number;
  paymentDetectedAt?: string;
  detectionMethod?: 'in-page-dom' | 'booked-history-poll' | 'simulated';
  ticketRef?: string;
}

export interface BookingJob {
  id: string;
  req: BookingRequest;
  stage: BookingStage;
  status: BookingStatus;
  events: BookingEvent[];
  createdAt: string;
  updatedAt: string;
  result?: BookingResult;
  /** prompt shown to the user when status === awaiting_user */
  awaiting?: { kind: 'captcha' | 'payment' | 'review'; prompt: string };
}

export function pushEvent(job: BookingJob, stage: BookingStage, message: string, level: BookingEvent['level'] = 'info', data?: Record<string, unknown>) {
  job.events.push({ at: new Date().toISOString(), stage, message, level, data });
  job.stage = stage;
  job.updatedAt = new Date().toISOString();
  if (job.events.length > 200) job.events.splice(0, job.events.length - 200);
}
