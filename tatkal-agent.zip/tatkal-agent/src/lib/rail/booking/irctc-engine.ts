/**
 * LIVE IRCTC booking driver (Playwright).
 *
 * ⚠️ EXPERIMENTAL — drives www.irctc.co.in in a real (headed-when-available)
 * Chromium. Flow: login (captcha assisted by user) → search → Book Now →
 * passenger fill → review → submit → payment handoff → Option A payment
 * detection (in-page DOM watch for confirmation + PNR).
 *
 * IRCTC changes markup frequently; selectors are centralised below and every
 * step logs events so failures are diagnosable from the UI timeline.
 */
import { chromium, type BrowserContext, type Page } from 'playwright-core';
import fs from 'fs';
import path from 'path';
import { pushEvent, type BookingJob } from './types';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function chromiumPath(): string | null {
  const base = path.join(process.env.HOME ?? '/home/z', '.cache', 'ms-playwright');
  if (!fs.existsSync(base)) return null;
  const dirs = fs.readdirSync(base).filter((d) => d.startsWith('chromium-')).sort();
  for (const d of dirs.reverse()) {
    const p = path.join(base, d, 'chrome-linux', 'chrome');
    if (fs.existsSync(p)) return p;
  }
  return null;
}

const SEL = {
  loginBtn: 'a[aria-label="Login"], .loginlink',
  userId: 'input[formcontrolname="userid"]',
  password: 'input[formcontrolname="password"]',
  captchaInput: 'input[formcontrolname="captcha"]',
  signIn: 'button[type="submit"]:has-text("SIGN IN")',
  fromStation: 'input[aria-controls="origin input"]',
  toStation: 'input[aria-controls="destination input"]',
  dateInput: 'input[aria-label^="Journey Date"], #jDate input',
  searchBtn: 'button:has-text("Search")',
  bookNow: (trainNo: string) => `div:has-text("${trainNo}") >> button:has-text("Book Now")`,
  passengerName: (i: number) => `input[formcontrolname="passengerName"]:nth-match(input[formcontrolname="passengerName"], ${i + 1})`,
  passengerAge: (i: number) => `input[formcontrolname="passengerAge"]:nth-match(input[formcontrolname="passengerAge"], ${i + 1})`,
  continueBtn: 'button:has-text("Continue")',
  paymentUpi: 'text=UPI',
  payNow: 'button:has-text("Pay")',
};

async function ensurePage(job: BookingJob): Promise<{ ctx: BrowserContext; page: Page }> {
  const exe = chromiumPath();
  if (!exe) throw new Error('Chromium not found in playwright cache');
  const userDataDir = path.join(process.cwd(), '.irctc-profile');
  fs.mkdirSync(userDataDir, { recursive: true });
  const ctx = await chromium.launchPersistentContext(userDataDir, {
    executablePath: exe,
    headless: false,
    viewport: { width: 1366, height: 850 },
    args: ['--disable-blink-features=AutomationControlled'],
  });
  const page = ctx.pages()[0] ?? (await ctx.newPage());
  pushEvent(job, 'login', 'Browser context ready (persistent profile).');
  return { ctx, page };
}

/**
 * Option A payment detection — watches the live page for the booking
 * confirmation without any user input: polls DOM for success markers and
 * also listens for navigations to the confirmation route.
 */
async function detectPaymentInPage(job: BookingJob, page: Page, timeoutMs = 10 * 60_000): Promise<{ pnr?: string }> {
  const start = Date.now();
  const markers = ['ticket has been booked', 'booking is confirmed', 'pnr', 'transaction successful', 'payment successful'];
  while (Date.now() - start < timeoutMs) {
    await sleep(3000);
    try {
      if (page.isClosed()) throw new Error('Page closed before payment confirmation');
      const text = (await page.evaluate(() => document.body?.innerText ?? '')).toLowerCase();
      const hit = markers.find((m) => text.includes(m));
      if (hit) {
        const pnrMatch = /(?:pnr|pnr no\.?)\s*[:#]?\s*(\d{10})/i.exec(text);
        pushEvent(job, 'payment_detect', `In-page confirmation marker found ("${hit}").`, 'success');
        return { pnr: pnrMatch?.[1] };
      }
      pushEvent(job, 'payment_detect', `Poll ${Math.round((Date.now() - start) / 3000)}: no confirmation marker yet…`);
    } catch (e) {
      pushEvent(job, 'payment_detect', `Poll error: ${e instanceof Error ? e.message : 'unknown'}`, 'warn');
      if (page.isClosed()) throw e;
    }
  }
  throw new Error('Payment detection timed out');
}

export async function runLiveBooking(job: BookingJob, captchaAnswer: () => Promise<string>): Promise<void> {
  const { req } = job;
  let ctx: BrowserContext | null = null;
  try {
    if (!req.irctcUser) throw new Error('IRCTC username required for live mode');
    const { ctx: c, page } = await ensurePage(job);
    ctx = c;

    pushEvent(job, 'login', 'Opening irctc.co.in…');
    await page.goto('https://www.irctc.co.in/nget/train-search', { waitUntil: 'domcontentloaded', timeout: 45000 });
    await page.click(SEL.loginBtn, { timeout: 15000 });
    await page.fill(SEL.userId, req.irctcUser, { timeout: 10000 });

    // Password + captcha are requested through the UI gate — never stored.
    job.status = 'awaiting_user';
    job.awaiting = { kind: 'captcha', prompt: 'Enter your IRCTC password and the captcha shown in the browser window (format: password|captcha)' };
    pushEvent(job, 'captcha', 'Waiting for password + captcha from user.', 'warn');
    const answer = await captchaAnswer();
    job.status = 'running';
    job.awaiting = undefined;
    const [password, captcha] = answer.split('|');
    if (!password || !captcha) throw new Error('Expected password|captcha');
    await page.fill(SEL.password, password);
    await page.fill(SEL.captchaInput, captcha.toUpperCase());
    await page.click(SEL.signIn, { timeout: 10000 });
    await sleep(3500);
    pushEvent(job, 'login', 'Sign-in submitted.', 'success');

    pushEvent(job, 'search_fill', `Filling ${req.fromCode} → ${req.toCode}, ${req.date}, class ${req.cls}`);
    await page.fill(SEL.fromStation, req.fromCode);
    await page.keyboard.press('ArrowDown');
    await page.keyboard.press('Enter');
    await page.fill(SEL.toStation, req.toCode);
    await page.keyboard.press('ArrowDown');
    await page.keyboard.press('Enter');
    await page.fill(SEL.dateInput, req.date.split('-').reverse().join('-'));
    await page.click(SEL.searchBtn, { timeout: 10000 });
    await sleep(4000);

    pushEvent(job, 'search_fill', `Looking for train ${req.trainNo} → Book Now`);
    await page.click(SEL.bookNow(req.trainNo), { timeout: 20000 });
    await sleep(2500);

    pushEvent(job, 'passengers', `Filling ${req.passengers.length} passenger(s)`);
    for (let i = 0; i < req.passengers.length; i++) {
      const p = req.passengers[i];
      await page.fill(SEL.passengerName(i), p.name);
      await page.fill(SEL.passengerAge(i), String(p.age));
      await page.selectOption(`${SEL.passengerAge(i)} >> xpath=../..//select`, p.gender).catch(() => {});
      await sleep(300);
    }

    job.status = 'awaiting_user';
    job.awaiting = { kind: 'review', prompt: 'Check the browser window: verify passengers, quota, class. Type CONTINUE to proceed.' };
    const go = await captchaAnswer();
    job.status = 'running';
    job.awaiting = undefined;
    if (go.trim().toUpperCase() !== 'CONTINUE') throw new Error('User aborted at review');

    await page.click(SEL.continueBtn, { timeout: 10000 });
    await sleep(2500);
    pushEvent(job, 'submit', 'Details submitted to IRCTC.', 'success');

    pushEvent(job, 'payment', 'Selecting UPI payment…');
    await page.click(SEL.paymentUpi, { timeout: 15000 }).catch(() => {});
    await page.click(SEL.payNow, { timeout: 15000 }).catch(() => {});
    job.status = 'awaiting_user';
    job.awaiting = { kind: 'payment', prompt: 'Complete the payment in the opened window. The agent auto-detects the confirmation (Option A) — leave the window open.' };
    pushEvent(job, 'payment', 'Payment handoff — user completes payment; detection running.', 'warn');
    // user signals by typing PAID (detection continues independently)
    const paySignal = await Promise.race([captchaAnswer(), sleep(2 * 60_000).then(() => 'TIMEOUT')]);
    job.status = 'running';
    job.awaiting = undefined;
    if (paySignal !== 'PAID') pushEvent(job, 'payment', 'No explicit signal — continuing in-page detection anyway.', 'warn');

    const { pnr } = await detectPaymentInPage(job, page);
    job.status = 'success';
    job.result = {
      pnr: pnr ?? '(PNR not parsed — check booked history)',
      paymentDetectedAt: new Date().toISOString(),
      detectionMethod: 'in-page-dom',
    };
    pushEvent(job, 'ticket', `Booking confirmed${pnr ? ' — PNR ' + pnr : ''}. e-ticket available in the IRCTC window.`, 'success');
    pushEvent(job, 'done', 'Live booking flow complete.', 'success');
  } catch (e) {
    job.status = 'failed';
    pushEvent(job, 'failed', e instanceof Error ? e.message : 'Unknown live failure', 'error');
  } finally {
    // keep browser open briefly so user can download ticket / inspect
    if (ctx) setTimeout(() => ctx!.close().catch(() => {}), 120_000);
  }
}
