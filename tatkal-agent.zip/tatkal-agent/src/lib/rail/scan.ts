/**
 * Scan orchestrator — live-first with graceful degradation.
 *
 * Train list + fares + availability come from erail (LIVE).
 * When a specific class has no live fare, the corrected static engine
 * produces an estimate marked "EST". Availability is never invented.
 */
import { fetchTrainsLive, istToday, upcomingRunDates } from './erail';
import { convenienceFeeFor, estimateFare } from './fares';
import { getStation, resolveStation } from './stations';
import type { ClassFareAvl, ScanResult, TrainOption } from './types';

interface CacheEntry {
  at: number;
  trains: TrainOption[];
}
const CACHE_TTL_MS = 5 * 60 * 1000;
const cache = new Map<string, CacheEntry>();

export interface ScanParams {
  from: string;
  to: string;
  date?: string; // yyyy-mm-dd; default = tomorrow
  quota?: 'GN' | 'TQ';
}

function tomorrow(): string {
  const d = new Date(Date.now() + 5.5 * 3600 * 1000 + 24 * 3600 * 1000);
  return d.toISOString().slice(0, 10);
}

export interface ScanRow {
  train: TrainOption;
  /** per-class view prepared for the UI under the requested quota */
  classRows: {
    cls: string;
    fare: number | null;
    fareSource: 'live' | 'estimated';
    fareKnown: boolean;
    convenienceFee: number;
    breakdown: import('./types').FareBreakdown | null;
    /** availability for the requested journey date */
    avl: import('./types').AvlState | null;
    avlDate: string | null;
  }[];
}

export async function scanTrains(params: ScanParams): Promise<ScanResult & { rows?: ScanRow[] }> {
  const from = resolveStation(params.from);
  const to = resolveStation(params.to);
  if (!from || !to) {
    return {
      fromCode: params.from, fromName: params.from, toCode: params.to, toName: params.to,
      date: params.date ?? tomorrow(), quota: params.quota ?? 'TQ',
      source: 'live', fetchedAt: new Date().toISOString(), trains: [],
      error: `Unknown station code: ${!from ? params.from : params.to}`,
    };
  }
  const date = params.date ?? tomorrow();
  const quota = params.quota ?? 'TQ';
  const cacheKey = `${from.code}->${to.code}`;
  const cached = cache.get(cacheKey);
  let trains: TrainOption[];
  let source: 'live' | 'fallback';
  let note: string | undefined;

  if (cached && Date.now() - cached.at < CACHE_TTL_MS) {
    trains = cached.trains;
    source = 'live';
    note = 'cached snapshot (< 5 min old)';
  } else {
    try {
      const res = await fetchTrainsLive(from.code, to.code);
      trains = res.trains;
      source = 'live';
      cache.set(cacheKey, { at: Date.now(), trains });
    } catch (e) {
      return {
        fromCode: from.code, fromName: from.name, toCode: to.code, toName: to.name,
        date, quota, source: 'fallback', fetchedAt: new Date().toISOString(), trains: [],
        error: `Live fetch failed (${e instanceof Error ? e.message : 'unknown'}). Retry in a moment — the scan screen needs live data.`,
      };
    }
  }

  const rows: ScanRow[] = trains.map((t) => {
    const classRows = t.classes.map((c: ClassFareAvl) => {
      let fare: number | null = null;
      let fareSource: 'live' | 'estimated' = 'live';
      let breakdown: import('./types').FareBreakdown | null = null;
      if (quota === 'TQ') {
        if (c.tqKnown && c.tqTotal != null) fare = c.tqTotal;
      } else if (c.gnTotal != null) {
        fare = c.gnTotal;
      }
      if (fare == null && t.distanceKm) {
        const est = estimateFare(c.cls, t.distanceKm, t.type, quota);
        if (est) {
          fare = est.total;
          fareSource = 'estimated';
          breakdown = est;
        }
      }
      // availability cell matching the requested journey date
      let avl: import('./types').AvlState | null = null;
      let avlDate: string | null = null;
      if (c.avl.length > 0) {
        const exact = c.avl.find((a) => a.date === date);
        if (exact) {
          avl = exact.state;
          avlDate = exact.date;
        } else {
          // prefer the first cell on/after the journey date; else nearest known
          const next = c.avl.find((a) => a.date >= date);
          const pick = next ?? c.avl[0];
          avl = pick.state;
          avlDate = pick.date;
        }
      }
      return {
        cls: c.cls,
        fare,
        fareSource,
        fareKnown: fare != null,
        convenienceFee: convenienceFeeFor(c.cls),
        breakdown,
        avl,
        avlDate,
      };
    });
    return { train: t, classRows };
  });

  return {
    fromCode: from.code, fromName: from.name, toCode: to.code, toName: to.name,
    date, quota, source, fetchedAt: new Date().toISOString(), trains, rows, note,
  };
}

export { istToday, upcomingRunDates, getStation };
