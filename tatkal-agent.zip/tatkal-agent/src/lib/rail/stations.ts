import { STATIONS, STATION_ALIASES } from './stations-data';
import type { Station } from './types';

let index: Map<string, Station> | null = null;
let aliasIndex: Map<string, string[]> | null = null;
let lowerNameIndex: Map<string, Station[]> | null = null;

function build() {
  index = new Map();
  lowerNameIndex = new Map();
  aliasIndex = new Map();
  for (const [code, name, region] of STATIONS) {
    const st: Station = { code, name, region };
    index.set(code, st);
    const key = name.toLowerCase();
    const arr = lowerNameIndex.get(key) ?? [];
    arr.push(st);
    lowerNameIndex.set(key, arr);
  }
  for (const [code, alias] of STATION_ALIASES) {
    const arr = aliasIndex.get(alias.toLowerCase()) ?? [];
    arr.push(code);
    aliasIndex.set(alias.toLowerCase(), arr);
  }
}

export function allStations(): Station[] {
  if (!index) build();
  return [...index!.values()];
}

export function getStation(code: string): Station | undefined {
  if (!index) build();
  return index!.get(code.trim().toUpperCase());
}

export function stationName(code: string): string {
  return getStation(code)?.name ?? code;
}

/**
 * Search stations by code or (fuzzy) name.
 * Ranking: exact code > code prefix > name starts-with > name contains;
 * ties broken by region priority (Kerala=2, South=1) then shorter name.
 */
export function searchStations(query: string, limit = 8): Station[] {
  if (!index) build();
  const q = query.trim().toLowerCase();
  if (!q) {
    // Default suggestions: Kerala + South India hubs first
    return allStations()
      .filter((s) => ['TVC', 'ERS', 'ERN', 'QLN', 'KTYM', 'CLT', 'KYJ', 'TCR', 'PGTN', 'ALLP', 'CAN', 'KGQ', 'OTR', 'OTP'].includes(s.code))
      .slice(0, limit);
  }
  const qu = query.trim().toUpperCase();
  type Scored = { s: Station; rank: number };
  const out: Scored[] = [];
  const push = (s: Station, rank: number) => out.push({ s, rank });

  const byCode = index!.get(qu);
  if (byCode) push(byCode, 0);

  for (const [code] of index!) {
    if (code !== qu && code.startsWith(qu)) {
      push(index!.get(code)!, 1);
    }
  }
  for (const [key, arr] of lowerNameIndex!) {
    for (const s of arr) {
      if (key === q) push(s, 2);
      else if (key.startsWith(q)) push(s, 3);
      else if (key.includes(q)) push(s, 4);
    }
  }
  for (const [alias, codes] of aliasIndex!) {
    if (alias === q || alias.startsWith(q) || alias.includes(q)) {
      for (const c of codes) {
        const s = index!.get(c);
        if (s) push(s, 3.5);
      }
    }
  }
  // dedupe keeping best rank
  const best = new Map<string, number>();
  for (const { s, rank } of out) {
    const cur = best.get(s.code);
    if (cur === undefined || rank < cur) best.set(s.code, rank);
  }
  return [...best.entries()]
    .sort((a, b) => {
      if (a[1] !== b[1]) return a[1] - b[1];
      const ra = index!.get(a[0])!.region, rb = index!.get(b[0])!.region;
      if (ra !== rb) return rb - ra; // higher region first
      const na = index!.get(a[0])!.name.length, nb = index!.get(b[0])!.name.length;
      if (na !== nb) return na - nb;
      return a[0].localeCompare(b[0]);
    })
    .slice(0, limit)
    .map(([code]) => index!.get(code)!);
}

/** Resolve user input ("ERS", "Ernakulam", "Kochi") to a station, or null. */
export function resolveStation(input: string): Station | null {
  if (!input.trim()) return null;
  const direct = getStation(input);
  if (direct) return direct;
  const results = searchStations(input, 1);
  return results[0] ?? null;
}
