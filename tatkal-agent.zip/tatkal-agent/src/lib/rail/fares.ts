/**
 * STATIC fare engine — FALLBACK ONLY (badge "EST").
 *
 * Base fares come from a lookup table calibrated against LIVE erail fares
 * (scripts/calibrate-fares.py, ~30 routes / 3600+ samples, piecewise-linear
 * telescopic interpolation). Charges follow official IRCTC rules:
 *  - reservation + superfast charges per class
 *  - Tatkal: 10% of base (2S), 30% (all other classes) with min/max caps
 *    (observed live caps post-hike: SL 200, 3A/3E 420, 2A 525)
 *  - GST 5% on AC classes (applied on fare incl. charges)
 *  - IRCTC convenience fee: ₹17.70 non-AC / ₹35.40 AC (₹15/₹30 + 18% GST)
 */
import calibration from './fares-calibration.json';
import type { BookingClass, FareBreakdown } from './types';
import { AC_CLASSES } from './types';

const LUT = calibration.lut as Record<string, [number, number][]>;

export const RESERVATION_CHARGE: Record<string, number> = {
  '2S': 15, SL: 20, '3A': 40, '3E': 40, CC: 50, '2A': 50, '1A': 60, EA: 60, EC: 60,
};

export const SUPERFAST_CHARGE: Record<string, number> = {
  '2S': 15, SL: 30, '3A': 45, '3E': 45, CC: 45, '2A': 75, '1A': 75, EA: 75, EC: 75,
};

export const TATKAL_RULES: Record<string, { pct: number; min: number; max: number } | null> = {
  '2S': { pct: 10, min: 10, max: 15 },
  SL: { pct: 30, min: 100, max: 200 },
  '3A': { pct: 30, min: 300, max: 420 },
  '3E': { pct: 30, min: 300, max: 420 },
  CC: { pct: 30, min: 125, max: 225 },
  '2A': { pct: 30, min: 400, max: 525 },
  '1A': null, // no Tatkal on First AC / Executive
  EA: null,
  EC: null,
};

export const CONVENIENCE_FEE: Record<string, number> = { AC: 35.4, NON_AC: 17.7 };

const SUPERFAST_TYPES = new Set(['SUPERFAST', 'RAJDHANI', 'DURONTO', 'HUMSAFAR', 'VANDE_BHARAT']);

function interpLut(cls: string, distKm: number): number | null {
  const lut = LUT[cls];
  if (!lut || lut.length === 0) return null;
  if (distKm <= lut[0][0]) return lut[0][1];
  if (distKm >= lut[lut.length - 1][0]) return lut[lut.length - 1][1];
  for (let i = 0; i < lut.length - 1; i++) {
    const [d1, v1] = lut[i];
    const [d2, v2] = lut[i + 1];
    if (distKm >= d1 && distKm <= d2) {
      const t = (distKm - d1) / (d2 - d1);
      return v1 + t * (v2 - v1);
    }
  }
  return null;
}

export function estimateBaseFare(cls: string, distKm: number): number | null {
  if (!distKm || distKm <= 0) return null;
  const base = interpLut(cls, Math.round(distKm));
  return base ? Math.round(base) : null;
}

/** Estimated total fare breakdown (fallback when live fare missing). */
export function estimateFare(cls: string, distKm: number, trainType: string, quota: 'GN' | 'TQ'): FareBreakdown | null {
  const base = estimateBaseFare(cls, distKm);
  if (base === null) return null;
  const reservation = RESERVATION_CHARGE[cls] ?? 20;
  const superfast = SUPERFAST_TYPES.has(trainType.toUpperCase()) ? SUPERFAST_CHARGE[cls] ?? 0 : 0;
  let tatkal = 0;
  if (quota === 'TQ') {
    const rule = TATKAL_RULES[cls];
    if (rule) {
      tatkal = Math.min(Math.max((base * rule.pct) / 100, rule.min), rule.max);
      tatkal = Math.round(tatkal);
    } else {
      return null; // class not bookable under Tatkal
    }
  }
  const isAc = AC_CLASSES.has(cls);
  const taxable = base + reservation + superfast + tatkal;
  const gst = isAc ? Math.round(taxable * 0.05) : 0;
  const convenience = isAc ? CONVENIENCE_FEE.AC : CONVENIENCE_FEE.NON_AC;
  const total = Math.ceil(taxable + gst + convenience);
  return { base, reservation, superfast, tatkal, gst, convenience, total };
}

/** Per-ticket IRCTC convenience fee added on top of live fare totals. */
export function convenienceFeeFor(cls: string): number {
  return AC_CLASSES.has(cls) ? CONVENIENCE_FEE.AC : CONVENIENCE_FEE.NON_AC;
}

export type { BookingClass, FareBreakdown };
